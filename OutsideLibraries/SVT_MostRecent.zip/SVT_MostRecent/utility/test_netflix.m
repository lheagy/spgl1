clear all;close all; 

% define random seed
s = RandStream('mt19937ar','Seed',1);
RandStream.setGlobalStream(s);

%% Add SPGL1 path and run Ropt Scripts

% addpath(genpath('/scratch/slic/rkumar/MaxNormPaper1/SISC/SISC_Review/Reim_Opt'));
% addpath(genpath('/users/slic/rkumar/solver/Sasha_Version'));
% addpath(genpath('/users/slic/rkumar/Self_Function'));
% run RiemannianMatrixCompletion_6Jan2014/startup.m
% run RiemannianMatrixCompletion_6Jan2014/Install_mex.m
% run SVT_MostRecent/private/install_mex.m
%% Read data 
params.real = 1;
D=dlmread('/Volumes/Users/rkumar/Dropbox/Research/Low-Rank/Matrix_Pareto_Factorization/SLIM.Projects.MatrixParetoFact/scripts/Exp_Proxy_versus_true_nuclear_norm/SISC_Review/Table_8_1_2/forsasha/ratings.dat');
userid=6040;
movie=3952;
%Define the intial incomplete matrix
Dinit=zeros(userid,movie);
l=length(D(:,1));
% fill the matrix with the given data
for Z=1:l
    k=D(Z,1);
    m=D(Z,3);
    Dinit(k,m)=D(Z,5);
end
Dtest=vec(Dinit);
%% Define mask to further remove 50% of the data
ind=find(Dtest); 
ind1=randperm(length(ind));
% data Initilization
ind2=ind1(1:floor(length(ind1)/2));
ind3 = setdiff(ind1,ind2); % test indices
ind3 = ind(ind3);
prob.Omega=ind(ind2); % indices where data is non-zero
b=Dtest(prob.Omega); % subset of data 
Dtest(ind3)=0;
Dtest = sparse(Dtest);
%% Define paramete for SPGL1
prob.n1 = userid;
prob.n2 = movie;
[prob.Omega_i, prob.Omega_j] = ind2sub([prob.n1,prob.n2], prob.Omega);
prob.m = length(prob.Omega);
params.afun = @(L,R)XonOmega(L,R,prob.Omega_i,prob.Omega_j);
params.afunT = @(x)sparse(prob.Omega_i, prob.Omega_j,x,prob.n1,prob.n2,prob.m);
opts = spgSetParms('optTol',1e-6, ...
                    'bpTol', 1e-6,...
                    'decTol',1e-4,...
                    'project', @TraceNorm_project, ...
                    'primal_norm', @TraceNorm_primal, ...
                    'dual_norm', @TraceNorm_dual, ...
                    'proxy', 1, ...
                    'ignorePErr', 1, ...
                    'iterations', 10);
params.nr=10;
params.numr = userid;
params.numc = movie;
params.ls = 1;
params.mode=1;
params.funForward = @NLfunForward_partXY;
[U,S,V] = svds(reshape(params.afunT(b),6040,3952), params.nr, 'L', opts);
Linit=U*sqrt(S);
Rinit=V*sqrt(S);
xinit  = [vec(Linit);vec(Rinit)]; % Initial guess
tau = norm(xinit,1);
sigmafact = 1e-2;
sigma=sigmafact*norm(params.afunT(b),'fro');
opts.funPenalty = @funLS;
profile('-memory','on'); 
[xLS,r1,g1,info] = spgl1General(@NLfunForward_partXY,b,tau,sigma,xinit,opts,params);
e = params.numr*params.nr;
%% Compute the SNR
L1 = xLS(1:e);
R1 = xLS(e+1:end);
L1 = reshape(L1,params.numr,params.nr);
R1 = reshape(R1,params.numc,params.nr);
xls = L1*R1';
xls=vec(xls);
Drec=xls(ind3);
Dorig=vec(Dinit);
Dorigtest=Dorig(ind3);
SNR = -20*log10(norm(Dorigtest-Drec,'fro')/norm(Dorigtest,'fro'))
