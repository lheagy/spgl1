cd Auxiliary

% Extracting a subset of entries of a matrix 
mex partXY.c

% Update a sparse matrix 
mex updateSval.c
    
% BLAS versions if needed...    
mex -lmwlapack -lmwblas  partXY_blas.c
mex -lmwlapack -lmwblas  updateSval_blas.c    

cd ..