addpath Code
addpath Auxiliary
addpath Examples
